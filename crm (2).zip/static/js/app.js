
// Message/Notification timer
// Otro comentario de prueba en js
var message_timeout = document.getElementById("message-timer");

setTimeout(function()

{

    message_timeout.style.display = "none";


}, 3000);

